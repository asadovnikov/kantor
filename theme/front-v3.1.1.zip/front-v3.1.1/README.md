# Welcome to Front – Multipurpose Responsive Template! #

Front Template by Htmlstream

### Documentation and Getting Started ###

The overall development documentation is available at `documentation/index.html` and Gulp documentation at `documentation/getting-started/gulp.html`.

Below is quick steps to run Gulp:

- npm install
- gulp

Yup, that's it.

### License ###

Front is licensed under Bootstrap Themes and you can find more detailed information about it here: https://themes.getbootstrap.com/licenses

### Theme Support ###

Have a question? No worries! Front comes with 6 months of free support. We take seriously every issue that is reported to us, and we aim to resolve each one as quickly as possible. Feel free to “Contact Us” at https://htmlstream.com/contact-us

### Need Front Template customization? ###

We offer affordable, professional and trendy customized design solutions, solely for your own projects! Front Template can be easily customized with its cutting-edge components and features. However, if you feel you need any further customization please drop us a message at https://htmlstream.com/hire-us and our dedicated team will assist you with your inquiries.